function doBanner() {

	d('BannerContainer').addEventListener('click', function(){ window.open(clickTag,"_blank") });

	TweenMax.to([d('loader'),d('fader')], 0.5, {autoAlpha:0})

	function frame_1() {
		//d('interior').style.opacity ='1';
		TweenMax.to(d('textbacker'), 0.75, {y:"-=300", ease:Sine.easeInOut, delay:1});
		TweenMax.from(d('splitholder'), 0.75, {y:"+=50", ease:Sine.easeInOut, delay:1});
		TweenMax.to(d('interior'), 1, {autoAlpha:1, delay:1.25});
		TweenMax.to(d('interior'), 5.5, {scale:1.1, rotation:0.01, ease:Sine.easeIn, delay:1});
		TweenMax.to([d('logo'),d('ctaContainer')], 0.5, {autoAlpha:1, delay:2});
		TweenMax.to(d('headline1'), 0.5, {autoAlpha:1, delay:2});
		TweenMax.to(d('interior'), 1, {autoAlpha:0, delay:5});
		TweenMax.to(d('headline1'), 1, {autoAlpha:0, delay:5});
		TweenMax.delayedCall(6, frame_2);
	};

	function frame_2() {
		TweenMax.to(d('carscene'), 1, {autoAlpha:1});
		TweenMax.from(d('carscene'), 7, {x:"-=160", rotation:0.01, ease:Sine.easeInOut});
		TweenMax.to(d('headline2'), 0.5, {autoAlpha:1, delay:0});
		TweenMax.delayedCall(7, frame_3);
	}

	function frame_3() {
		TweenMax.to(d('textbacker'), 0.5, {y:"+=300", ease:Sine.easeInOut, delay:0});
		TweenMax.to(d('splitholder'), 0.5, {y:"+=50", ease:Sine.easeInOut, delay:0});
		TweenMax.to(d('carscene'), 1, {autoAlpha:0, delay:0});
		TweenMax.to(d('headline2'), 0.5, {autoAlpha:0});
		TweenMax.to(d('headline3'), 0.5, {autoAlpha:1, delay:1});
		TweenMax.to(d('subhead3'), 0.5, {autoAlpha:1, delay:1});
		TweenMax.to(d('award'), 0.5, {autoAlpha:1, delay:1});
		TweenMax.delayedCall(3.5, frame_4);
	}

	function frame_4() {
		TweenMax.to([d('headline3'),d('subhead3'),d('award'),d('ctaContainer')], 0.5, {autoAlpha:0});
		TweenMax.to([d('headline4'),d('carsolo')], 0.5, {autoAlpha:1, delay:0.5});
		TweenMax.to([d('finance'),d('caveatButton')], 0.5, {autoAlpha:1, delay:1});
		TweenMax.delayedCall(1, handleCaveat);
		TweenMax.delayedCall(4, frame_5);
	}

	function frame_5() {
		handleLongDealerName();
		TweenMax.to([d('headline4'),d('finance')], 0.5, {autoAlpha:0});
		TweenMax.to([d('headline5'),d('retailer')], 0.5, {autoAlpha:1, delay:0.5});
		TweenMax.to([d('ctaContainer'),d('caveatBtnContainer')], 0.5, {autoAlpha:1, delay:0.5});
	}

	frame_1();

}

/// HELPERS

function d(e) {
	return document.getElementById(e);
}

function handleCaveat() {

	var isOpen = false;

	d('caveatBtnContainer').addEventListener('click', caveatToggle);
	d('closeBtn').addEventListener('click', caveatToggle);

	function caveatToggle(e) {
		var target;
		e.stopPropagation();
		isOpen ? target = 0 : target = 1;
		TweenMax.to(d('caveatPanel'), 0.2, {autoAlpha:target});
		isOpen = !isOpen;
	}
}

function handleLongDealerName() {
	var twoLineHeight = 28;
	var ctaCurrentY = parseInt(window.getComputedStyle(d('ctaContainer')).top, 10);
	var dealerHeight = d('retailer').offsetHeight;
	d('ctaContainer').style.top = (ctaCurrentY + (dealerHeight - twoLineHeight)) + "px";
}